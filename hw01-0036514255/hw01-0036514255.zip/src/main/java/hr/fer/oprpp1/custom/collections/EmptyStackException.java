package hr.fer.oprpp1.custom.collections;

public class EmptyStackException extends RuntimeException{

}
